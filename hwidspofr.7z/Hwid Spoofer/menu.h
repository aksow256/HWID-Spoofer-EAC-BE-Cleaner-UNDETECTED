#pragma once
#include "icons.h"
#include "globals.h"
#include "includes.h"

namespace Menu
{
	void Theme();
	void Render();
}